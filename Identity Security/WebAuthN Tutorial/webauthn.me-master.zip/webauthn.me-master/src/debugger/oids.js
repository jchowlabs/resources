export default {
  '1.2.840.113549.1.1.11': 'sha256WithRSAEncryption'
};
