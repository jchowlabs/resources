export default {
  authenticatorAvailable: 'Authenticator available',
  authenticatorNotAvailable: 'No authenticators available',
  authenticatorAvailableNotSupported:
    'API call not supported: isUserVerifyingPlatformAuthenticatorAvailable()'
};
