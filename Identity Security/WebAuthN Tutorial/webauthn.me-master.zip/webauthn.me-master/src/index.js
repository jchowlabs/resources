// import { setupDebugger } from './debugger';
import log from 'loglevel';

log.setLevel('debug');

// setupDebugger();
